#!/system/bin/sh
SKIPUNZIP=1

# 多语言检测
locale=$(getprop persist.sys.locale | tr '[:upper:]' '[:lower:]')
[ -z "$locale" ] && locale="zh"
ui_print "- $locale"
case $locale in
  en*) language=en ;;
  *)   language=zh ;;
esac
i18n_print() {
  [ "$language" = "zh" ] && ui_print "$2" || ui_print "$1"
}

# 检测所有Hosts模块
i18n_print "- Checking for Hosts modules" "- 正在检测Hosts模块"
found_hosts=false;for module in /data/adb/modules/*;do [ -f "$module/system/etc/hosts" ]&&[ -f "$module/module.prop" ]&&{ [ "$found_hosts" = false ]&&i18n_print "- Found Hosts modules, auto-removing:" "- 发现Hosts模块，正在自动移除:"&&found_hosts=true;ui_print "  $(grep_prop name "$module/module.prop")";touch "$module/remove";};done
[ "$found_hosts" = true ]&&i18n_print "- Conflicting modules have been marked for removal. Please reboot after installation." "- 冲突模块已标记移除，安装完成后请重启设备。"

AGH_DIR="/data/adb/agh"
BIN_DIR="$AGH_DIR/bin"
SCRIPT_DIR="$AGH_DIR/scripts"
BACKUP_DIR="$AGH_DIR/backup"
ADGPATH="/data/adb/modules/AdGuardHome"
PROXY_SCRIPT="$AGH_DIR/scripts/ProxyConfig.sh"

i18n_print "- Extracting basic module files" "- 正在解压模块基本文件"
for file in uninstall.sh module.prop service.sh action.sh; do
  unzip -o "$ZIPFILE" "$file" -d "$MODPATH"
done

# 正在停止ProxyConfig
[ -f "$AGH_DIR/scripts/ProxyConfig.sh" ] && {
    i18n_print "- Stopping ProxyConfig process" "- 正在终止ProxyConfig进程"
    pkill -9 "ProxyConfig"
}

# 检查并停止运行中的进程
if [ -d "$AGH_DIR" ]; then
i18n_print "- Stopping all AdGuard Home processes" "- 正在终止AdGuard Home进程"
pkill -9 "AdGuardHome"
fi

# 正在停止NoAdsService
[ -f "$AGH_DIR/scripts/NoAdsService.sh" ] && {
    i18n_print "- Stopping NoAdsService process" "- 正在终止NoAdsService进程"
    pkill -9 "NoAdsService"
}

# 正在停止ProxyConfig
[ -f "$AGH_DIR/scripts/ProxyConfig.sh" ] && {
    i18n_print "- Stopping ProxyConfig process" "- 正在终止ProxyConfig进程"
    pkill -9 "ProxyConfig"
}

# 删除被锁定的残留文件
[ -f "$AGH_DIR/scripts/NoAdsService.sh" ] && {
    i18n_print "- Removing locked residual files" "- 正在删除被锁定的残留文件"
    local c=0 u=0 p;while IFS= read -r p;do [ -n "$p" ]&&[ -e "$p" ]&&while IFS= read -r f;do c=$((c+1));if [ -d "$f" ];then lsattr -d "$f" |grep -q "i-"&&{ chattr -i "$f";rmdir "$f"&&u=$((u+1));} else lsattr "$f" |grep -q "i-"&&{ chattr -i "$f";rm -f "$f";u=$((u+1));};fi;done< <(find "$p" \( -type f -o -type d \));done< <(grep 'block_ad' "$AGH_DIR/scripts/NoAdsService.sh"|grep -o '".*"'|tr -d '"')
    i18n_print "- Removed $u locked files out of $c scanned items" "- 从 $c 个文件中删除了 $u 个锁定文件"
}

# 检查是否首次安装
if [ -d "$AGH_DIR" ]; then
  i18n_print "- Backing up configuration" "- 正在备份配置文件"
  mkdir -p "$BACKUP_DIR"
  [ -f "$BIN_DIR/AdGuardHome.yaml" ] && cp -f "$BIN_DIR/AdGuardHome.yaml" "$BACKUP_DIR/"
  [ -f "$SCRIPT_DIR/config.prop" ] && cp -f "$SCRIPT_DIR/config.prop" "$BACKUP_DIR/"
  [ -f "$SCRIPT_DIR/NoAdsService.sh" ] && cp -f "$SCRIPT_DIR/NoAdsService.sh" "$BACKUP_DIR/"
fi

# 解锁脚本防篡改保护
if [ -d "$SCRIPT_DIR" ]; then
    i18n_print "- Unlocking old script files" "- 正在解锁旧脚本文件"
    find "$AGH_DIR/scripts" "$ADGPATH" -type f -name "*.sh" -exec chattr -i {} \;
fi

# 清除旧模块残留
if [ -d "$AGH_DIR/ifw" ] || [ -d "$AGH_DIR/scripts" ] || [ -d "$BIN_DIR/agh_pid" ] || [ -d "$BIN_DIR/data/filters" ]; then
  i18n_print "- Cleaning up old module residues" "- 正在清理旧模块残留"
  rm -rf "$AGH_DIR/ifw" "$AGH_DIR/scripts" "$BIN_DIR/agh_pid" "$BIN_DIR/data/filters"
fi

# 创建目录并解压文件
mkdir -p "$AGH_DIR" "$BIN_DIR" "$SCRIPT_DIR" "$BACKUP_DIR"
i18n_print "- Extracting AdGuardHome files" "- 正在解压 AdGuardHome 文件"
unzip -o "$ZIPFILE" "scripts/*" -d "$AGH_DIR"
unzip -o "$ZIPFILE" "bin/*" -d "$AGH_DIR"
i18n_print "- Setting permissions" "- 设置权限"
find "$AGH_DIR" -type d -exec chmod 0700 {} \;
chmod +x "$BIN_DIR/AdGuardHome" 
chmod +x "$SCRIPT_DIR"/*.sh
chown root:net_raw "$BIN_DIR/AdGuardHome"

# 执行脚本防篡改保护
i18n_print "- Locking script files" "- 正在锁定脚本文件"
find "$SCRIPT_DIR" -type f -name "*.sh" -exec chattr +i {} \;

# ════════════════════
# 音量键端口模式选择
# ════════════════════
KEY_FIFO=$(mktemp -u -p /dev/tmp)
KEY_LISTENER_PID=""

start_key_listener() {
    [ -n "$KEY_LISTENER_PID" ] && kill -0 "$KEY_LISTENER_PID" 2>/dev/null && return
    mkfifo "$KEY_FIFO" || return 1
    getevent -ql > "$KEY_FIFO" &
    KEY_LISTENER_PID=$!
}

stop_key_listener() {
    [ -n "$KEY_LISTENER_PID" ] && kill "$KEY_LISTENER_PID" >/dev/null 2>&1
    [ -n "$KEY_FIFO" ] && rm -f "$KEY_FIFO"
    KEY_LISTENER_PID=""
}

volume_key_detection() {
    local timeout_seconds="${1:-10}"
    local detection_result_file=$(mktemp -u -p /dev/tmp)
    (
        while read -r line; do
            if echo "$line" | grep -Eiq "(KEY_)?VOLUME ?UP|KEYCODE_VOLUME_UP" && echo "$line" | grep -Eiq "DOWN|PRESS"; then
                echo "0" > "$detection_result_file"
                exit 0
            elif echo "$line" | grep -Eiq "(KEY_)?VOLUME ?DOWN|KEYCODE_VOLUME_DOWN" && echo "$line" | grep -Eiq "DOWN|PRESS"; then
                echo "1" > "$detection_result_file"
                exit 0
            fi
        done < "$KEY_FIFO"
    ) &
    local detection_pid=$!
    (
        sleep "$timeout_seconds"
        if kill -0 "$detection_pid" 2>/dev/null; then
            kill "$detection_pid" 2>/dev/null
            echo "2" > "$detection_result_file"
        fi
    ) &
    local timeout_pid=$!
    wait "$detection_pid" 2>/dev/null
    kill "$timeout_pid" 2>/dev/null
    wait "$timeout_pid" 2>/dev/null
    [ -f "$detection_result_file" ] && { local result=$(cat "$detection_result_file"); rm -f "$detection_result_file"; return "$result"; }
    rm -f "$detection_result_file"
    return 2
}

handle_choice() {
    local question="$1"
    local choice_yes="${2:-随机端口}"
    local choice_no="${3:-固定端口}"
    local timeout_seconds="${4:-10}"
    ui_print " "
    ui_print "-----------------------------------------------------------"
    ui_print "- ${question}"
    ui_print "- [ 音量加(+) ]: ${choice_yes}"
    ui_print "- [ 音量减(-) ]: ${choice_no}"
    ui_print "- [ ${timeout_seconds}秒内未选择将默认选择: ${choice_yes} ]"
    timeout 0.1 getevent -c 1 >/dev/null 2>&1
    start_key_listener
    volume_key_detection "$timeout_seconds"
    local result=$?
    stop_key_listener
    if [ "$result" -eq 0 ]; then
        ui_print "  => 您选择了: ${choice_yes}"
        return 0
    elif [ "$result" -eq 1 ]; then
        ui_print "  => 您选择了: ${choice_no}"
        return 1
    else
        ui_print "  => 超时未选择，默认选择: ${choice_yes}"
        return 0
    fi
}

MODE_FILE="$AGH_DIR/.port_mode"
PORT_MODE="random"
if [ -d "/data/adb/box" ]; then
    if handle_choice "检测到 Box 模块，选择 DNS 端口模式？" "随机端口(自动同步给Box)" "固定端口5591(自动同步给Box)"; then
        PORT_MODE="random"
    else
        PORT_MODE="fixed"
    fi
else
    if handle_choice "未检测到 Box 模块，选择 DNS 端口模式？" "随机端口(推荐)" "固定端口"; then
        PORT_MODE="random"
    else
        PORT_MODE="fixed"
    fi
fi
echo "$PORT_MODE" > "$MODE_FILE"
i18n_print "- Port mode set to: $PORT_MODE" "- 端口模式已设置为: $PORT_MODE"

# 正在保留配置文件
if [ -f "$BACKUP_DIR/config.prop" ]; then
  i18n_print "- Preserving configuration file" "- 正在保留配置文件"
  cp -f "$BACKUP_DIR/config.prop" "$SCRIPT_DIR/"
  # 清理残留的代理订阅链接，避免泄露且本模块不管理代理订阅
  sed -i 's|^PROXY_URL=.*|PROXY_URL=""|' "$SCRIPT_DIR/config.prop"
fi
i18n_print "- Installation complete. Reboot device." "- 安装完成，请重启设备。"