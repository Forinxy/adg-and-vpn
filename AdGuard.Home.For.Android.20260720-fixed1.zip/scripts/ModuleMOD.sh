#!/system/bin/sh
SCRIPTS_DIR="/data/adb/agh/scripts"
MOD_PATH=${MODPATH:-/data/adb/modules/AdGuardHome}
LAST_LOCALE="INIT"
MODE_FILE="/data/adb/agh/.port_mode"

# 防止重复启动
[ "$(pgrep -f "$0" | wc -l)" -gt 1 ] && exit

# 语言检测相关
while true; do
  CURRENT_LOCALE=$(getprop persist.sys.locale)
  [ -z "$CURRENT_LOCALE" ] && CURRENT_LOCALE="zh" 
  PORT_MODE="fixed"
  [ -f "$MODE_FILE" ] && PORT_MODE=$(cat "$MODE_FILE")
  if [ "$LAST_LOCALE" = "INIT" ] || [ "$LAST_LOCALE" != "$CURRENT_LOCALE" ] || [ "$PORT_MODE" != "$LAST_MODE" ]; then
    if [ "$PORT_MODE" = "random" ]; then
      if [[ "$CURRENT_LOCALE" == zh* ]]; then
        sed -i "s|^description=.*|description=DNS层面过滤广告、防DNS劫持，随机端口模式：检测到 Box 自动同步 DNS 端口共存，无 Box 独立劫持53，管理器页面点击操作按钮进入，不要私自更改内置规则和配置，账号和密码均为root|" "$MOD_PATH/module.prop"
      else
        sed -i "s|^description=.*|description=DNS-level ad blocking and anti-DNS hijacking. Random port mode: auto-syncs DNS port with Box if present, else hijacks port 53 standalone. Click the action button on the Manager page to proceed. Do not modify built-in rules or configuration. login: root/root.|" "$MOD_PATH/module.prop"
      fi
    else
      if [[ "$CURRENT_LOCALE" == zh* ]]; then
        sed -i "s|^description=.*|description=DNS层面过滤广告、防DNS劫持，固定端口5591模式：检测到 Box 自动同步 DNS 端口共存，无 Box 自动转随机独立，管理器页面点击操作按钮进入，不要私自更改内置规则和配置，账号和密码均为root|" "$MOD_PATH/module.prop"
      else
        sed -i "s|^description=.*|description=DNS-level ad blocking and anti-DNS hijacking. Fixed port 5591 mode: auto-syncs DNS port with Box if present, falls back to random standalone otherwise. Click the action button on the Manager page to proceed. Do not modify built-in rules or configuration. login: root/root.|" "$MOD_PATH/module.prop"
      fi
    fi
    sed -i "s|^author=.*|author=ChunmengWuhen |" "$MOD_PATH/module.prop"
    LAST_LOCALE="$CURRENT_LOCALE"
    LAST_MODE="$PORT_MODE"
  fi

# 延迟启动
  sleep 5
done