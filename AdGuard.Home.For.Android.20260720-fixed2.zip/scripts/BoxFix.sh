#!/system/bin/sh
# BoxFix v5 自适应协调器 + 故障自动降级
#  - Box 存在   -> AGH 作为广告过滤上游（不劫持 53），mihomo nameserver 自动同步到 AGH 实际 DNS 端口
#                  random 模式随机端口、fixed 模式固定 5591，两者均自动同步
#  - Box 不存在 -> AGH 随机端口独立模式，iptables 劫持 53 做广告过滤
# 安装顺序无关，独立使用兼容，全程无需用户干预
CFG="/data/adb/box/mihomo/config.yaml"
BOX_DIR="/data/adb/box"
RESTART_CMD="/data/adb/box/scripts/box.service restart"
LOG="/data/adb/agh/agh.log"
MODE_FILE="/data/adb/agh/.port_mode"
SCRIPT_DIR="/data/adb/agh/scripts"
BIN_DIR="/data/adb/agh/bin"
MARK="/data/adb/box/mihomo/.agh_fixed_v41"
YAML="$BIN_DIR/AdGuardHome.yaml"

[ "$(pgrep -f "$0" | wc -l)" -gt 1 ] && exit

log() { echo "$(date '+%F %T') [BoxFix] $*" >> "$LOG"; }

box_installed() {
  [ -d "$BOX_DIR" ] && [ -f "$CFG" ]
}

# 检查代理服务器是否可达
proxy_reachable() {
  # 读取代理服务器地址（从 mihomo 配置）
  local server=$(awk '/proxies:/,/^\s*name:/' "$CFG" | grep "server:" | awk '{print $2}' | head -1)
  [ -z "$server" ] && return 0
  timeout 3 ping -c 1 "$server" >/dev/null 2>&1
}

# 检查 AGH DNS 端口是否可达
agh_port_reachable() {
  local PORT="$1"
  timeout 2 ss -tln 2>/dev/null | grep -q ":${PORT} " || timeout 2 netstat -tln 2>/dev/null | grep -q ":${PORT} "
}

get_agh_port() {
  local p
  p=$(awk '/^[[:space:]]*dns:/{f=1;next} f&&/^[[:space:]]*port:/{gsub(/[^0-9]/,"",$NF);print $NF;exit}' "$YAML" 2>/dev/null)
  [ -z "$p" ] && p=$(sed -n 's/^redir_port=//p' "$SCRIPT_DIR/config.prop" 2>/dev/null)
  echo "$p"
}

is_synced() {
  local PORT="$1"
  [ -f "$CFG" ] || return 1
  [ -n "$PORT" ] || return 1
  grep -q '^[[:space:]]*enhanced-mode:[[:space:]]*fake-ip' "$CFG" || return 1
  grep -q "127\.0\.0\.1:$PORT" "$CFG" || return 1
  return 0
}

sync_mihomo() {
  local PORT="$1"
  [ -f "$CFG" ] || { log "未找到 $CFG，跳过同步"; return 0; }
  [ -n "$PORT" ] || { log "AGH 端口未知，跳过同步"; return 0; }
  mkdir -p "$(dirname "$CFG")"
  [ -f "$CFG.aghbak" ] || cp -f "$CFG" "$CFG.aghbak"
  log "同步 mihomo 到 AGH 端口 $PORT ..."

  # 智能 DNS 模式：国内 CDN 域名（抖音/B站等）走 redir-host 直接解析，快
  # 代理域名保留 fake-ip 精确控制
  sed -i 's/^\([[:space:]]*enhanced-mode:\).*/\1 fake-ip/' "$CFG"

  # 更新 fake-ip-filter：添加抖音/B站等国内 CDN 域名，让它们跳过 fake-ip
  # 先清空旧的 fake-ip-filter 内容
  sed -i '/^  fake-ip-filter:/,/^[^ ]/{ /^    - .*/d }' "$CFG"

  # 确保 fake-ip-filter 存在并写入规则
  if ! grep -q 'fake-ip-filter' "$CFG"; then
    # 不存在则插入
    awk '
    /^dns:/ { in_dns=1 }
    in_dns && /^  enhanced-mode:/ {
      print
      print "  fake-ip-filter:"
      print "    - regex:\\\\.cn$"
      print "    - regex:\\\\.acg\\.cn$"
      print "    - regex:\\\\.bilibili\\.com$"
      print "    - regex:\\\\.bilivideo\\.com$"
      print "    - regex:\\\\.b23\\.tv$"
      print "    - regex:\\\\.ixigua\\.com$"
      next
    }
    {print}
    ' "$CFG" > "$CFG.tmp" && mv "$CFG.tmp" "$CFG"
  else
    # 已存在则在 fake-ip-filter 块内追加规则
    awk '
    /^  fake-ip-filter:/ { in_filter=1; print; next }
    in_filter && /^[^ ]/ {
      print "    - regex:\\\\.cn$"
      print "    - regex:\\\\.acg\\.cn$"
      print "    - regex:\\\\.bilibili\\.com$"
      print "    - regex:\\\\.bilivideo\\.com$"
      print "    - regex:\\\\.b23\\.tv$"
      print "    - regex:\\\\.ixigua\\.com$"
      in_filter=0
    }
    {print}
    ' "$CFG" > "$CFG.tmp" && mv "$CFG.tmp" "$CFG"
  fi

  sed -i "s/^\([[:space:]]*-[[:space:]]*\)127\.0\.0\.1:[0-9]*/\1127.0.0.1:$PORT/" "$CFG"
  grep -q '^[[:space:]]*nameserver:' "$CFG" || \
    awk -v port="$PORT" '/^dns:/{print; print "  nameserver:"; print "    - 127.0.0.1:" port; next}1' "$CFG" > "$CFG.tmp" && mv "$CFG.tmp" "$CFG"

  sed -i '/^tun:/,/^[^ ]/{s/^\([[:space:]]*enable:\).*/\1 true/;}' "$CFG"
  sed -i '/^sniffer:/,/^[^ ]/{s/^\([[:space:]]*enable:\).*/\1 true/;}' "$CFG"

  awk 'BEGIN{skip=0} /^[[:space:]]*-[[:space:]]*name:[[:space:]]*Local_DNS_Forward/{skip=1;next} skip && /^[[:space:]]*-[[:space:]]*name:/{skip=0} !skip' "$CFG" > "$CFG.tmp" && mv "$CFG.tmp" "$CFG"

  touch "$MARK"
  log "配置同步完成，重启 Box ..."
  $RESTART_CMD
}

# 降级到直连模式
degrade_to_direct() {
  log "检测到网络故障，降级到直连模式..."
  [ -f "$CFG.aghbak" ] || { log "无备份，跳过降级"; return 1; }
  cp -f "$CFG.aghbak" "$CFG"
  sed -i 's/^\([[:space:]]*enable:\).*/\1 false/' "$CFG"  # 禁用 tun
  sed -i 's/enhanced-mode: fake-ip/enhanced-mode: redir-host/' "$CFG"  # 改用 redir-host
  $RESTART_CMD
  log "已降级到直连模式"
}

restart_agh() {
  pkill -9 "AdGuardHome"; sleep 1
  export SSL_CERT_DIR="/system/etc/security/cacerts/"
  "$BIN_DIR/AdGuardHome" --no-check-update &
}

cleanup_standalone() {
  pkill -9 "ProxyConfig"; pkill -9 "iptables.sh"
  iptables -w 2 -t nat -F ADGUARD 2>/dev/null; iptables -w 2 -t nat -X ADGUARD 2>/dev/null
  ip6tables -w 2 -D OUTPUT -p udp --dport 53 -j DROP 2>/dev/null
  ip6tables -w 2 -D OUTPUT -p tcp --dport 53 -j DROP 2>/dev/null
}

switch_to_standalone() {
  log "未检测到 Box，切换到独立模式"
  echo "random" > "$MODE_FILE"
  R1=$((30000+RANDOM%35536)); R2=$((30000+RANDOM%35536))
  sed -i "s/^\([[:space:]]*port:\) [0-9]*/\1 $R1/; s/^\([[:space:]]*address:\) 127\.0\.0\.1:[0-9]*/\1 127.0.0.1:$R2/" "$YAML"
  sed -i "s/^redir_port=.*/redir_port=$R1/" "$SCRIPT_DIR/config.prop" || echo "redir_port=$R1" > "$SCRIPT_DIR/config.prop"
  restart_agh
  "$SCRIPT_DIR/iptables.sh" &
  "$SCRIPT_DIR/ProxyConfig.sh" &
}

current_mode() {
  [ -f "$MODE_FILE" ] && cat "$MODE_FILE" || echo "unknown"
}

# 状态跟踪
degraded=0
last_proxy_ok=1
check_count=0

while true; do
  MODE=$(current_mode)
  if box_installed; then
    cleanup_standalone
    AGH_PORT=$(get_agh_port)
    
    # 检查代理健康
    if proxy_reachable; then
      if [ "$last_proxy_ok" -eq 0 ]; then
        log "代理已恢复，重新同步配置"
        degraded=0; rm -f "/data/adb/box/mihomo/.degraded"
      fi
      last_proxy_ok=1
      is_synced "$AGH_PORT" || sync_mihomo "$AGH_PORT"
    else
      if [ "$last_proxy_ok" -eq 1 ]; then
        log "警告：代理不可达，开始监控"
        last_proxy_ok=0
      fi
      check_count=$((check_count + 1))
      
      # 连续失败 3 次后降级（避免误判）
      if [ $check_count -ge 3 ] && [ "$degraded" -eq 0 ]; then
        degrade_to_direct
        degraded=1; touch "/data/adb/box/mihomo/.degraded"
        check_count=0
      fi
    fi
  else
    rm -f "/data/adb/box/mihomo/.degraded" 2>/dev/null
    [ "$MODE" != "random" ] && switch_to_standalone || {
      pgrep -f "iptables.sh" >/dev/null || "$SCRIPT_DIR/iptables.sh" &
      pgrep -f "ProxyConfig.sh" >/dev/null || "$SCRIPT_DIR/ProxyConfig.sh" &
    }
  fi
  sleep 30
done &
